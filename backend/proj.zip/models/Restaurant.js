const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const request = require('supertest');
const express = require('express');

// Mock auth middleware BEFORE routes are required
jest.mock('../middleware/auth', () => {
  const protect = (req, res, next) => {
    req.user = {
      id: req.headers['x-user-id'] || new mongoose.Types.ObjectId().toHexString(),
      role: req.headers['x-user-role'] || 'user',
    };
    next();
  };
  const authorize = (...roles) => (req, res, next) => {
    if (roles.includes(req.user.role)) return next();
    return res.status(403).json({ success: false, message: 'Forbidden' });
  };
  return { protect, authorize };
});

let mongod;
let app;
let server;
let Reservation;
let Restaurant;

beforeAll(async () => {
  mongod = await MongoMemoryServer.create();
  const uri = mongod.getUri();

  await mongoose.connect(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  // require models after mongoose connect
  Reservation = require('../models/Reservation');
  Restaurant = require('../models/Restaurant');

  // build express app
  app = express();
  app.use(express.json());

  // mount real routes (they will use mocked auth)
  const reservationsRouter = require('../routes/reservations');
  const restaurantsRouter = require('../routes/restaurants');

  app.use('/reservations', reservationsRouter);
  app.use('/restaurants', restaurantsRouter);

  server = app.listen(); // ephemeral
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongod.stop();
  await server.close();
});

beforeEach(async () => {
  await Reservation.deleteMany({});
  await Restaurant.deleteMany({});
});

describe('Reservations controller - full coverage', () => {
  const VALID_DATETIME = '2025-11-02T19:00:00Z'; // requested canonical datetime
  const VALID_DATETIME_20 = '2025-11-02T20:00:00Z';
  const OUTSIDE_DATETIME = '2025-11-02T23:30:00Z'; // outside 10-22
  const EARLY_DATETIME = '2025-11-02T02:00:00Z'; // for overnight tests (02:00)
  const ANY_USER_ID = new mongoose.Types.ObjectId().toHexString();
  const OTHER_USER_ID = new mongoose.Types.ObjectId().toHexString();
  const ADMIN_ID = new mongoose.Types.ObjectId().toHexString();

  let restaurant;

  beforeEach(async () => {
    // create restaurant matching your schema: include postalcode and required fields
    restaurant = await Restaurant.create({
      name: 'Test Restaurant',
      address: '123 Test St',
      district: 'Test District',
      province: 'Test Province',
      postalcode: '10110',
      tel: '+66-2-987-6543',
      openTime: '10:00',
      closeTime: '22:00',
      image: 'no-photo.jpg'
    });
  });

  test('CREATE reservation success (admin can create for any user) -> 201', async () => {
    const res = await request(app)
      .post(`/restaurants/${restaurant._id}/reservations`)
      .set('x-user-role', 'admin')
      .send({
        user: ANY_USER_ID,
        dateTime: VALID_DATETIME
      });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toHaveProperty('_id');
    expect(res.body.data.user).toBe(ANY_USER_ID);
    expect(res.body.data.restaurant).toBe(String(restaurant._id));
    // dateTime stored as ISO string; ensure equal
    expect(new Date(res.body.data.dateTime).toISOString()).toBe(VALID_DATETIME);
  });

  test('CREATE reservation fails when restaurant not found -> 404', async () => {
    const fakeId = new mongoose.Types.ObjectId().toHexString();
    const res = await request(app)
      .post(`/restaurants/${fakeId}/reservations`)
      .set('x-user-role', 'admin')
      .send({
        user: ANY_USER_ID,
        dateTime: VALID_DATETIME
      });

    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/No restaurant with the id/i);
  });

  test('CREATE reservation fails when dateTime missing -> 400', async () => {
    const res = await request(app)
      .post(`/restaurants/${restaurant._id}/reservations`)
      .set('x-user-role', 'admin')
      .send({
        user: ANY_USER_ID
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toBe('dateTime is required');
  });

  test('CREATE reservation fails when user missing -> 400', async () => {
    const res = await request(app)
      .post(`/restaurants/${restaurant._id}/reservations`)
      .set('x-user-role', 'admin')
      .send({
        dateTime: VALID_DATETIME
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toBe('user is required in request body');
  });

  test('CREATE reservation fails if outside working hours -> 400', async () => {
    const res = await request(app)
      .post(`/restaurants/${restaurant._id}/reservations`)
      .set('x-user-role', 'admin')
      .send({
        user: ANY_USER_ID,
        dateTime: OUTSIDE_DATETIME
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(String(res.body.message)).toMatch(/outside restaurant working hours/i);
  });

  test('CREATE reservation limit: non-admin cannot exceed 3 -> 400', async () => {
    // create 3 existing reservations for ANY_USER_ID
    await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });
    await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME_20 });
    await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });

    // now try create as non-admin
    const res = await request(app)
      .post(`/restaurants/${restaurant._id}/reservations`)
      .set('x-user-role', 'user')
      .send({
        user: ANY_USER_ID,
        dateTime: VALID_DATETIME
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(String(res.body.message)).toMatch(/already made 3 reservations/i);
  });

  test('GET /reservations - admin sees all, user sees only own', async () => {
    const r1 = await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });
    const r2 = await Reservation.create({ user: OTHER_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });

    // admin
    const resAdmin = await request(app)
      .get('/reservations')
      .set('x-user-role', 'admin')
      .set('x-user-id', ADMIN_ID);

    expect(resAdmin.status).toBe(200);
    expect(resAdmin.body.success).toBe(true);
    expect(resAdmin.body.count).toBe(2);

    // specific user ANY_USER_ID
    const resUser = await request(app)
      .get('/reservations')
      .set('x-user-role', 'user')
      .set('x-user-id', ANY_USER_ID);

    expect(resUser.status).toBe(200);
    expect(resUser.body.success).toBe(true);
    expect(resUser.body.count).toBe(1);
    expect(resUser.body.data[0]._id).toBe(String(r1._id));
  });

  test('GET /restaurants/:restaurantId/reservations returns only that restaurant', async () => {
    const otherRestaurant = await Restaurant.create({
      name: 'Other',
      address: 'Other',
      district: 'D',
      province: 'P',
      postalcode: '10200',
      tel: '000',
      openTime: '10:00',
      closeTime: '22:00'
    });

    const r1 = await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });
    const r2 = await Reservation.create({ user: ANY_USER_ID, restaurant: otherRestaurant._id, dateTime: VALID_DATETIME });

    const res = await request(app)
      .get(`/restaurants/${restaurant._id}/reservations`)
      .set('x-user-role', 'admin');

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.count).toBe(1);
    expect(res.body.data[0]._id).toBe(String(r1._id));
    // ensure r2 not present
    expect(res.body.data.find(d => d._id === String(r2._id))).toBeUndefined();
  });

  test('GET /reservations/:id returns reservation or 404 when not found', async () => {
    const r = await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });

    const resOk = await request(app)
      .get(`/reservations/${r._id}`)
      .set('x-user-role', 'admin');

    expect(resOk.status).toBe(200);
    expect(resOk.body.success).toBe(true);
    expect(resOk.body.data._id).toBe(String(r._id));

    const notFound = await request(app)
      .get(`/reservations/${new mongoose.Types.ObjectId().toHexString()}`)
      .set('x-user-role', 'admin');

    // controller returns 404 when not found
    expect(notFound.status).toBe(404);
    expect(notFound.body.success).toBe(false);
  });

  test('UPDATE reservation success when admin or owner and dateTime valid -> 200', async () => {
    const r = await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });

    const res = await request(app)
      .put(`/reservations/${r._id}`)
      .set('x-user-role', 'admin') // admin can update
      .send({
        user: ANY_USER_ID,
        dateTime: '2025-11-02T20:00:00Z'
      });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(new Date(res.body.data.dateTime).toISOString()).toBe('2025-11-02T20:00:00.000Z');
  });

  test('UPDATE reservation fails when new dateTime outside hours -> 400', async () => {
    const r = await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });

    const res = await request(app)
      .put(`/reservations/${r._id}`)
      .set('x-user-role', 'admin')
      .send({
        user: ANY_USER_ID,
        dateTime: OUTSIDE_DATETIME
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(String(res.body.message)).toMatch(/outside restaurant working hours/i);
  });

  test('UPDATE reservation fails when non-owner non-admin -> 401', async () => {
    const r = await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });

    const res = await request(app)
      .put(`/reservations/${r._id}`)
      .set('x-user-role', 'user')
      .set('x-user-id', OTHER_USER_ID) // not the owner
      .send({
        user: OTHER_USER_ID,
        dateTime: '2025-11-02T20:00:00Z'
      });

    expect(res.status).toBe(401);
    expect(res.body.success).toBe(false);
  });

  test('DELETE reservation success for admin and actually removes doc -> 200', async () => {
    const r = await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });

    const res = await request(app)
      .delete(`/reservations/${r._id}`)
      .set('x-user-role', 'admin');

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);

    const found = await Reservation.findById(r._id);
    expect(found).toBeNull();
  });

  test('DELETE reservation fails when non-owner non-admin -> 401', async () => {
    const r = await Reservation.create({ user: ANY_USER_ID, restaurant: restaurant._id, dateTime: VALID_DATETIME });

    const res = await request(app)
      .delete(`/reservations/${r._id}`)
      .set('x-user-role', 'user')
      .set('x-user-id', OTHER_USER_ID);

    expect(res.status).toBe(401);
    expect(res.body.success).toBe(false);
  });

  test('CREATE with overnight schedule (open 20:00 close 03:00) handles times correctly', async () => {
    // make overnight restaurant
    const overnight = await Restaurant.create({
      name: 'Night Place',
      address: 'Night St',
      district: 'Night',
      province: 'Night',
      postalcode: '10200',
      tel: '000',
      openTime: '20:00',
      closeTime: '03:00'
    });

    // 22:00 same day -> valid
    const res1 = await request(app)
      .post(`/restaurants/${overnight._id}/reservations`)
      .set('x-user-role', 'admin')
      .send({
        user: ANY_USER_ID,
        dateTime: '2025-11-02T22:00:00Z'
      });

    expect(res1.status).toBe(201);
    expect(res1.body.success).toBe(true);

    // 02:00 next day -> valid
    const res2 = await request(app)
      .post(`/restaurants/${overnight._id}/reservations`)
      .set('x-user-role', 'admin')
      .send({
        user: ANY_USER_ID,
        dateTime: '2025-11-03T02:00:00Z'
      });

    expect(res2.status).toBe(201);

    // 12:00 -> invalid
    const res3 = await request(app)
      .post(`/restaurants/${overnight._id}/reservations`)
      .set('x-user-role', 'admin')
      .send({
        user: ANY_USER_ID,
        dateTime: '2025-11-03T12:00:00Z'
      });

    expect(res3.status).toBe(400);
  });

  test('UPDATE returns 404 when reservation not found', async () => {
    const fakeId = new mongoose.Types.ObjectId().toHexString();
    const res = await request(app)
      .put(`/reservations/${fakeId}`)
      .set('x-user-role', 'admin')
      .send({
        user: ANY_USER_ID,
        dateTime: VALID_DATETIME
      });

    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
  });

  test('DELETE returns 404 when reservation not found', async () => {
    const fakeId = new mongoose.Types.ObjectId().toHexString();
    const res = await request(app)
      .delete(`/reservations/${fakeId}`)
      .set('x-user-role', 'admin');

    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
  });
});
