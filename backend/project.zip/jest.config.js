module.exports = {
  testEnvironment: 'node',
  coverageDirectory: 'coverage',
  testTimeout: 10000,
};
